import React, { Component } from "react";
import Chart from "react-google-charts";

class Age extends Component {
  render () {
    return (
      <div>
      
        <div id="main__container__content">
          <h1>Age Breakdown</h1>
          
          <div class="graph_container">

          <Chart
            width={'100%'}
            height={'400px'}
            // Note here we use Bar instead of BarChart to load the material design version
            chartType="Bar"
            loader={<div>Loading Chart</div>}
            data={[
              ['Viewers age', 'Male', 'Female'],
              ['13, 17', 5070500, 6008000],
              ['18, 24', 7792000, 8694000],
              ['25, 35', 2695000, 2896000],
              ['35, 44', 2099000, 1953000],
              ['44, 65+', 1526000, 1517000],
            ]}
            options={{
              // Material chart options
              chart: {
                title: 'Audience by Age',
                subtitle: 'Based on male and female age data',
              },
              hAxis: {
                title: 'Total Population',
                minValue: 0,
              },
              vAxis: {
                title: 'Viewer age',
              },
              bars: 'vertical',
              axes: {
                y: {
                  0: { side: 'left' },
                },
              },
            }}
            // For tests
            rootProps={{ 'data-testid': '5' }}
          />

          </div>
        
        </div>

      </div>
    );
  }
}

export default Age;