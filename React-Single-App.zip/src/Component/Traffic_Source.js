import React, { Component } from "react";

// Importing the link file
import Keyword_Search from "./Keyword_Search";
import Gender from "./Gender";
import Age from "./Age";
import Country from "./Country"

// Improting the Router for the Routing between Pages
import { HashRouter, Route, NavLink } from "react-router-dom";

class Traffic_Source extends Component {
  render() {
    return (
      <div>
        <HashRouter>

          {/* <div class="main__container"> */}

            <div class="flex-container">
                
                <div>  
                  <ul>
                    <li><NavLink eaxct to="/Keyword_Search">Keyword Search</NavLink></li>
                  </ul>
                </div>
                
                <div>
                  <ul>
                    <li><NavLink to="/Gender">Gender</NavLink></li>
                  </ul>
                </div>
                
                <div>
                  <ul>
                    <li><NavLink to="/Age">Age</NavLink></li>
                  </ul>
                </div>  
                
                <div>
                  <ul>
                    <li><NavLink to="/Country">Country</NavLink></li>
                  </ul>
                </div>
              
              </div>

            {/* </div> */}

          <div className="Content">
            
            <Route exact path="/Keyword_Search" component={Keyword_Search} />
            <Route path="/Gender" component={Gender} />
            <Route path="/Age" component={Age} />
            <Route path="/Country" component={Country} />

          </div>
        
        </HashRouter>
      </div>
    );
  }
}

export default Traffic_Source;
