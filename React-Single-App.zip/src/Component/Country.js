import React, { Component } from "react";

class Country extends Component {
  render () {
    return (
      <div>

        <div class="main__content__container">
          <h1>Country Breakdown</h1>

          <div class="country__names">
            
              <button class="grid-item">India</button>
              <button class="grid-item">United States</button>
              <button class="grid-item">China</button>
              <button class="grid-item">Russia</button>
              <button class="grid-item">Europe</button>
              <button class="grid-item">Argentina</button>
              <button class="grid-item">Australia</button>
              <button class="grid-item">Sri Lanka</button>
              <button class="grid-item">Barcelona</button>
              <button class="grid-item">Spain</button>
              <button class="grid-item">Germany</button>
              <button class="grid-item">Pakistan</button>
              <button class="grid-item">Bangladesh</button>
              <button class="grid-item">Africa</button>
              <button class="grid-item">Country 15</button>
              <button class="grid-item">Country 16</button>
          
          </div>
          
        </div>
      
      </div>
    );
  }
}

  export default Country;