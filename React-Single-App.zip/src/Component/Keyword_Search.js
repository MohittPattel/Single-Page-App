import React, { Component } from "react";

class Keyword_Search extends Component {
  render() {
    return (
      <div>

        <div class="main__content__container">

          <h1 id="heading__keyword__search">Channel Keyword Search</h1>
          
          <div class="input-wrapper">
              <div class="search__box">
                  <input type="text" id="search" placeholder="Search.." />
                  <button type="submit"><p>🔍</p></button>
              </div>
          </div>

          <div class="channel__names">
            
            <button class="ch" type="button">Channel 1</button>
            <button class="ch">Channel 2</button>
            <button class="ch">Channel 3</button>
            <button class="ch">Channel 4</button>
            <button class="ch">Channel 5</button>
            <button class="ch">Channel 6</button>
            <button class="ch">Channel 7</button>
            <button class="ch">Channel 8</button>
            <button class="ch">Channel 9</button>
            <button class="ch">Channel 10</button>
            <button class="ch">Channel 11</button>
            <button class="ch">Channel 12</button>
            <button class="ch">Channel 13</button>
            <button class="ch">Channel 14</button>
            <button class="ch">Channel 15</button>
            <button class="ch">Channel 16</button>
          
          </div>

        </div>

      </div>
    );
  }
}

export default Keyword_Search;
