import React from "react";
import ReactDOM from "react-dom";

// Importing the main component
import Traffic_Source from "./Component/Traffic_Source";

// importing CSS File
import "./index.css";

ReactDOM.render(
    <Traffic_Source />,
    document.getElementById("root")
);
